Alisia Dragoon - Native Windows Recompilation
=============================================

No ROM is included. You must own and dump your own copy of
"Alisia Dragoon (USA)" for the Sega Mega Drive / Genesis.

Expected dump:
  size    1048576 bytes
  sha256  cb4e9c98de5a048ccdddf03bcfa5d8aad678c2399f4c5651075009c59836ffd2

How to run
----------
1. Put your ROM next to AlisiaDragoonRecomp.exe (e.g. alisia_usa.md).
2. Double-click AlisiaDragoonRecomp.exe and pick the ROM once.
   After that it boots straight in (rom-ALISIA.cfg + skip_launcher=1).

Controls (rebindable in settings.ini, sections [input.p1]..[input.p4])
--------
  D-Pad  Arrow keys       A  Z        B  X        C  C
  Start  Enter            6-button: X=A  Y=S  Z=D  Mode=Backspace
  Gamepad: SDL_GameController mapping, hot-pluggable

Save states / rewind
--------------------
  Shift+F1..F9  save slot      F1..F9  load slot
  F7 / F8       rewind / save-slot menu        Esc  menu
  Files: native_save_1..9.bin next to the exe

Diagnostics (optional)
----------------------
  AlisiaDragoonRecomp.exe --no-launcher --max-frames 950 <rom>
     prints "[FLOORCOUNT] entries=N" (68K interpreter fallbacks)
     and   "[Z80RC] fallback_unique_pcs=N" (Z80 interpreter fallbacks)

Notes
-----
- Do NOT use --turbo while testing audio: turbo disables playback by design.
- Source, build steps and measured evidence: https://github.com/ohackercego/AlisiaDragoonRecomp
- Alisia Dragoon is (c) Game Arts / Sega. Not affiliated or endorsed.
